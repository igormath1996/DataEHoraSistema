package com.mycompany.dataehorasistema;

import java.util.Date;

public class DataEHoraSistema {

    public static void main(String[] args) {
        Date relogio = new Date();
        System.out.println("Agora sao "+relogio);
        
    }
}